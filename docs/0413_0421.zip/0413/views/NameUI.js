// 📁 views/NamePromptUI.js
class NameUI extends UI {
    constructor() {
        super(images["background_default"], [
            {
                x: canvasWidth * 0.5,
                y: canvasHeight * 0.5,
                width: canvasWidth * 161/800,
                height: canvasHeight * 53/450,
                img: images["button_start"],
                imgLight: images["button_start_hover"],
                action: () => {
                    this.submitName();
                    textBoxFlag = true;
                }
            }
        ]);
    }

    draw() {
        super.draw();
        image(images["text_please_enter_a_nick_name"], 0, 0, canvasWidth, canvasHeight);
        if (!textBoxFlag) {
            // this.input = createInput();
            let input = createInput();
            // input.position(canvasWidth * 0.5, canvasHeight * 0.5);  // 依照畫面調整位置
            input.position((windowWidth - width) / 2, (windowHeight - height) / 2);  // 依照畫面調整位置
            input.size(508, 76);       // 視情況配合貼圖大小
            input.class('custom-input');  // 加上 CSS class

            // this.input.position(width / 2 - 100, height / 2 + 25);
            // this.input.size(200);
            // this.input.style('font-size', '16px');
            // this.input.style('padding', '8px');
            // this.input.style('border-radius', '6px');
            // this.input.style('border', '1px solid #ccc');
            // this.input.style('text-align', 'center');
            // this.input.style('outline', 'none');

            // this.button = createButton("Start");
            // this.button.position(width / 2 - 30, height / 2 + 80);
            // this.button.style('font-size', '16px');
            // this.button.style('padding', '8px 20px');
            // this.button.style('border-radius', '6px');
            // this.button.style('background-color', '#4CAF50');
            // this.button.style('color', 'white');
            // this.button.style('border', 'none');
            // this.button.style('cursor', 'pointer');
            // this.button.class('neon-button');
            // this.button.class('neon-button');
            // this.button.mouseOver(() => this.button.style('background-color', '#45a049'));
            // this.button.mouseOut(() => this.button.style('background-color', '#4CAF50'));
            // this.button.mousePressed(() => this.submitName());

            // textBoxFlag = true;
        }
        // push();
        // fill(255);
        // rectMode(CENTER);
        // rect(width / 2, height / 2, 600, 300, 10);
        // fill(0);
        // textSize(20);
        // textAlign(CENTER);
        // // Please enter a nickname.\nDo not use your real name for privacy reasons.\nYour nickname will be shown on the leaderboard at the end of the game:
        // text("Please enter a nickname", width / 2, height / 2 - 100);
        // textSize(14);
        // text("Do not use your real name for privacy reasons.", width / 2, height / 2 - 75);
        // text("Your nickname will be shown on the leaderboard at the end of the game:", width / 2, height / 2 -50);
        // // textSize(8);
        // text("(Only Start button games count for the leaderboard.)", width / 2, height / 2 -25);
        // pop();
    }

    submitName() {
        playerName = this.input.value() || "Unknown";
        localStorage.setItem("playerName", playerName);

        // 移除輸入 UI
        this.input.remove();
        this.button.remove();

        // GameController.start("level1");

        GameController.start("level1");

    }

}
