// 📁 models/DirectionWall.js
class DirectionWall extends Wall {
  constructor(x, y, img, type) {
    super(x, y, img, type);
    this.direction = [];
  }
}
